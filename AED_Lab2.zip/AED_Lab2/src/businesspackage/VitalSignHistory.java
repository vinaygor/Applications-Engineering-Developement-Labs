/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package businesspackage;

import java.util.ArrayList;

/**
 *
 * @author vinay
 */
public class VitalSignHistory {
    //defining an ArrayList of type VitalSigns
    private ArrayList<VitalSigns> vitalSignHistory;
    public VitalSignHistory(){
        //initializing the ArrayList object
        vitalSignHistory = new ArrayList<VitalSigns>();
    }
    

    public ArrayList<VitalSigns> getVitalSignHistory() {
        return vitalSignHistory;
    }

    public void setVitalSignHistory(ArrayList<VitalSigns> vitalSignHistory) {
        this.vitalSignHistory = vitalSignHistory;
    }
    
    public VitalSigns addVitals()
    {
        VitalSigns vs = new VitalSigns();
        vitalSignHistory.add(vs);
        return vs;
    }
    //method to delete the attributes
    public void deleteVitals(VitalSigns vs){
        vitalSignHistory.remove(vs);
    }
}
