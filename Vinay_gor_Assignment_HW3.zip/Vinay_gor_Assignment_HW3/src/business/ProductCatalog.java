/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.ArrayList;

/**
 *
 * @author vinay
 */
public class ProductCatalog {
    
    private ArrayList<Product> productList;
    private String vendorName;
    
    public ProductCatalog(){
        this.productList = new ArrayList<Product>();
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public ArrayList<Product> getProductList() {
        return productList;
    }

    public void setProductList(ArrayList<Product> productList) {
        this.productList = productList;
    }

    
    public Product addProduct(){
        Product product = new Product();
        productList.add(product);
        return product;
    }
    
    public void deleteProduct(Product product){
        productList.remove(product);
    }
    
    //public Product searchProduct(String name, String type, String vendor, String )
    
}
