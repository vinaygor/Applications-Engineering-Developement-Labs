/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.ArrayList;

/**
 *
 * @author vinay
 */
public class VendorCatalog {
    
    private ArrayList<Vendor> vendorList;

    public VendorCatalog() {
        this.vendorList = new ArrayList<Vendor>();
    }

    public ArrayList<Vendor> getVendorList() {
        return vendorList;
    }

    public void setVendorList(ArrayList<Vendor> vendorList) {
        this.vendorList = vendorList;
    }
    
    public Vendor addVendor(){
        Vendor vendor = new Vendor();
        vendorList.add(vendor);
        return vendor;
    }
    
    public void deleteVendor(Vendor vendor){
        vendorList.remove(vendor);
    }
    
}
