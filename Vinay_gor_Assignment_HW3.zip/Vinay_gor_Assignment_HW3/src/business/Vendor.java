/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

/**
 *
 * @author vinay
 */
public class Vendor {
    
    private String vendorName;
    private String vendorRegistrationNumber;
    private String username;
    private String password;

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public String getVendorRegistrationNumber() {
        return vendorRegistrationNumber;
    }

    public void setVendorRegistrationNumber(String vendorRegistrationNumber) {
        this.vendorRegistrationNumber = vendorRegistrationNumber;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    @Override
    public String toString(){
        return getVendorName();
    }
    
    
    
}
