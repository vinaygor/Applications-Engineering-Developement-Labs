/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package resumepackage;

import java.util.ArrayList;

/**
 *
 * @author vinay
 */
public class ResumeContainer {
    
    private ArrayList<PersonalInformation> resumeContainer;
    
    
    public ResumeContainer(){
        resumeContainer = new ArrayList<PersonalInformation>();
        
    }

    public ArrayList<PersonalInformation> getResumeContainer() {
        System.out.print("Inside getResume");
        return resumeContainer;
    }

    public void setResumeContainer(ArrayList<PersonalInformation> resumeContainer) {
        this.resumeContainer = resumeContainer;
    }

    
    public PersonalInformation addResume()
    {
        PersonalInformation personalInformation = new PersonalInformation();
        resumeContainer.add(personalInformation);
        return personalInformation;
    }
    
    public void deleteResume(PersonalInformation pi){
        resumeContainer.remove(pi);
    }
    
}
