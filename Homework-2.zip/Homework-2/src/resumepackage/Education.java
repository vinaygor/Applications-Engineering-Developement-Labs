/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package resumepackage;

/**
 *
 * @author vinay
 */
public class Education {
    
    //Declaring attributes of class Education
    private String degree1Title;
    private String degree1Date;
    private String university1;
    private String degree2Title;
    private String degree2Date;
    private String university2;
    private String degree3Title;
    private String degree3Date;
    private String university3;

    //Defining getters and setters for differen attributes
    public String getDegree1Title() {
        return degree1Title;
    }

    public void setDegree1Title(String degree1Title) {
        this.degree1Title = degree1Title;
    }

    public String getDegree1Date() {
        return degree1Date;
    }

    public void setDegree1Date(String degree1Date) {
        this.degree1Date = degree1Date;
    }

    public String getUniversity1() {
        return university1;
    }

    public void setUniversity1(String university1) {
        this.university1 = university1;
    }

    public String getDegree2Title() {
        return degree2Title;
    }

    public void setDegree2Title(String degree2Title) {
        this.degree2Title = degree2Title;
    }

    public String getDegree2Date() {
        return degree2Date;
    }

    public void setDegree2Date(String degree2Date) {
        this.degree2Date = degree2Date;
    }

    public String getUniversity2() {
        return university2;
    }

    public void setUniversity2(String university2) {
        this.university2 = university2;
    }

    public String getDegree3Title() {
        return degree3Title;
    }

    public void setDegree3Title(String degree3Title) {
        this.degree3Title = degree3Title;
    }

    public String getDegree3Date() {
        return degree3Date;
    }

    public void setDegree3Date(String degree3Date) {
        this.degree3Date = degree3Date;
    }

    public String getUniversity3() {
        return university3;
    }

    public void setUniversity3(String university3) {
        this.university3 = university3;
    }

    
    
}
