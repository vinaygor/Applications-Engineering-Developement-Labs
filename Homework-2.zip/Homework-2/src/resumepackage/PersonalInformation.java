/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package resumepackage;
import java.io.File;

/**
 *
 * @author vinay
 */
public class PersonalInformation {
    
    //defining the objects for class Address and class Education.
    public Address address;
    public Education education;
    public PersonalInformation(){
        //instantiating the objects for class Address and class Education
        address = new Address();
        education = new Education();
    }
    
    //Declaring attributes of class PersonalInformation
    private String firstName;
    private String lastName;
    private String affiliation;
    private String careerObjectiveStatement;
    private File file;
    private String phoneNumber;
    private String emailAddress;
    private String computerSkills;
    private String linkedInProfileLink;
    private String hobbies;
    private String month;
    private String date;
    private String year;
    private String workExperience;
    private String gender;
    private String graduation;

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getGraduation() {
        return graduation;
    }

    public void setGraduation(String graduation) {
        this.graduation = graduation;
    }

    public String getTypeOfStudent() {
        return typeOfStudent;
    }

    public void setTypeOfStudent(String typeOfStudent) {
        this.typeOfStudent = typeOfStudent;
    }
    private String typeOfStudent;
    

    //defining getters and setters for different attributes
    public String getWorkExperience() {
        return workExperience;
    }

    public void setWorkExperience(String workExperience) {
        this.workExperience = workExperience;
    }


    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAffiliation() {
        return affiliation;
    }

    public void setAffiliation(String affiliation) {
        this.affiliation = affiliation;
    }

    public String getCareerObjectiveStatement() {
        return careerObjectiveStatement;
    }

    public void setCareerObjectiveStatement(String careerObjectiveStatement) {
        this.careerObjectiveStatement = careerObjectiveStatement;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getComputerSkills() {
        return computerSkills;
    }

    public void setComputerSkills(String computerSkills) {
        this.computerSkills = computerSkills;
    }

    public String getLinkedInProfileLink() {
        return linkedInProfileLink;
    }

    public void setLinkedInProfileLink(String linkedInProfileLink) {
        this.linkedInProfileLink = linkedInProfileLink;
    }

    public String getHobbies() {
        return hobbies;
    }

    public void setHobbies(String hobbies) {
        this.hobbies = hobbies;
    }
    
    @Override
    public String toString(){
        return getFirstName();
    }
    
}
