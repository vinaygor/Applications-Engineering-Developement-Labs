/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.ArrayList;

/**
 *
 * @author vinay
 */
public class SupplierList {
    private ArrayList<Supplier> supplierList;

    public SupplierList() {
        supplierList = new ArrayList<Supplier>();
    }

    public ArrayList<Supplier> getSupplierList() {
        return supplierList;
    }

    public void setSupplierList(ArrayList<Supplier> supplierList) {
        this.supplierList = supplierList;
    }

    
    
    public Supplier addSupplier(){
         Supplier supplier=new Supplier();
         supplierList.add(supplier);
         return supplier;
    }
    
    public void removeVendor(Supplier supplier){
        supplierList.remove(supplier);
    }
    
    public Supplier searchSupplier(String key){
        for(Supplier supplier: supplierList){
           if(supplier.getSupplierName().equals(key)){
           return supplier;
           }
        }
        return null;
    }
}
