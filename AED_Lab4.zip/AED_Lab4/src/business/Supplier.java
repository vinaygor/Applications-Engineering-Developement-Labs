/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

/**
 *
 * @author vinay
 */
public class Supplier {
    private String supplierName;
   
   
    private ProductList productList;
   

    public Supplier(){
       productList=new ProductList();
     
    }
    
    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public ProductList getProductList() {
        return productList;
    }

    public void setProductList(ProductList productList) {
        this.productList = productList;
    }

    @Override
    public String toString(){
        return this.supplierName;
    }
    
    
    
}
