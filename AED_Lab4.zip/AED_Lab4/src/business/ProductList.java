/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import java.util.ArrayList;

/**
 *
 * @author vinay
 */
public class ProductList {
    private ArrayList<Product> productList;
     public ProductList(){
          productList=new ArrayList<Product>();
     }

    public ArrayList<Product> getProductList() {
        return productList;
    }

    public void setProductList(ArrayList<Product> productList) {
        this.productList = productList;
    }
     
     public Product addProduct(){
         Product product=new Product();
        productList.add(product);
        return product;
    }
    
    public void removeProduct(Product product){
        productList.remove(product);
    }
    
    public Product searchProduct(String key){
        for(Product product: productList){
           if(product.getModelNumber()==Integer.valueOf(key)){
           return product;
           }
        }
        return null;
    }
}
